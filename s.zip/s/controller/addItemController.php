<?php
session_start();
require_once'C:\xampp\htdocs\project1\connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['upload'])) {
    // Retrieve form data
    $ProductName = $_POST['product_name'];
    $desc = $_POST['product_desc'];
    $price = $_POST['price'];

    // Process file upload and other data
    $name = $_FILES['product_image']['name'];
    $temp = $_FILES['product_image']['tmp_name'];

    $location = "../images/";
    $image = $location . $name;

    $target_dir = "../images/";
    $finalImage = $target_dir . $name;

    move_uploaded_file($temp, $finalImage);

    // Perform database insertion
    $query1 = "INSERT INTO `product` (product_name, product_image, price, product_desc) VALUES (?, ?, ?, ?)";
    $stmt1 = mysqli_prepare($conn, $query1);

    if (!$stmt1) {
        echo "Error preparing statement: " . mysqli_error($conn);
        exit;
    }

    mysqli_stmt_bind_param($stmt1, "ssds", $ProductName, $finalImage, $price, $desc);
    $insert = mysqli_stmt_execute($stmt1);

    if (!$insert) {
        $error_message = mysqli_error($conn);

        // Check if it's a duplicate entry error
        if (strpos($error_message, 'Duplicate entry') !== false) {
            echo "Error: Duplicate entry. Please handle accordingly.";
        } else {
            echo "Error: $error_message";
        }
    } else {
        echo "Record added successfully.";
    }
}
?>
