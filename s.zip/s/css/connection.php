<?php
$hostname="localhost";
$username="root";
$password="123";
$db_name="login_db";
$tbl_name="login";
$connection=mysqli_connect($hostname,$username,$password,$db_name) or die('could not connect');
if(!$connection)
{
	echo"error: Unable to connect to mysqli_connect_errno();
	echo"<br> debugging errno:".mysqli_connect_error();
	exit;
}
else
{
	echo"connection successful";
}
?>